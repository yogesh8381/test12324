package com.example.jwtdecryptor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtDecryptorApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtDecryptorApplication.class, args);
	}

}
