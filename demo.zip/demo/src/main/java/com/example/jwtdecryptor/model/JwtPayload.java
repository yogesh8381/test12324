package com.example.jwtdecryptor.model;

public class JwtPayload {

    private String header;
    private String claims;

    public JwtPayload(String header, String claims) {
        this.header = header;
        this.claims = claims;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public String getClaims() {
        return claims;
    }

    public void setClaims(String claims) {
        this.claims = claims;
    }
}
