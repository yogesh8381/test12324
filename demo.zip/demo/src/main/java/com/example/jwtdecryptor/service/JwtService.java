package com.example.jwtdecryptor.service;

import com.example.jwtdecryptor.model.JwtPayload;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.util.Base64;
import java.util.Map;

@Service
public class JwtService {

    private final ObjectMapper objectMapper = new ObjectMapper();

    public JwtPayload decryptToken(String token) {
        if (token == null || !token.matches("^[A-Za-z0-9-_=]+\\.[A-Za-z0-9-_=]+\\.[A-Za-z0-9-_.+/=]*$")) {
            throw new IllegalArgumentException("Invalid JWT token format");
        }

        try {
            String[] tokenParts = token.split("\\.");
            String header = new String(Base64.getUrlDecoder().decode(tokenParts[0]));
            String claimsPart = new String(Base64.getUrlDecoder().decode(tokenParts[1]));

            Map<String, Object> headerMap = objectMapper.readValue(header, Map.class);
            Map<String, Object> claimsMap = objectMapper.readValue(claimsPart, Map.class);

            String formattedHeader = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(headerMap);
            String formattedClaims = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(claimsMap);

            return new JwtPayload(formattedHeader, formattedClaims);
        } catch (Exception e) {
            throw new RuntimeException("Invalid JWT token: " + e.getMessage());
        }
    }
}
